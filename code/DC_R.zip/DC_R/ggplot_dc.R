library(tidyverse) # Load the tidyverse

surveys <- read_csv("~/Desktop/DC_R/portal_data_joined.csv")

# Base R Version of removing missing data
surveys_complete <- surveys[!is.na(surveys$weight) | 
                              !is.na(surveys$hindfoot_length) | 
                              !is.na(surveys$sex),]

# dplyr version of the same above. 
# Ctrl-Shift-M (for pipe shortcut)
surveys_complete2 <- surveys %>% filter(!is.na(weight) | 
                                          !is.na(hindfoot_length) | 
                                          !is.na(sex))
# Take a look at the data
View(surveys_complete2)
View(surveys)

# Starting with ggplot! -------------------------
# First plot! Yay!
surveys_complete %>% 
  ggplot() +
  aes(x = weight, y = hindfoot_length) +
  geom_point()

# x %>% f(y) is same as f(x, y)
# The above is more sequential, but below is how most documentation
# will write their plots.
ggplot(data = surveys_complete, 
       mapping = aes(x = weight, y = hindfoot_length)) +
  geom_point()

# Other aesthetics:
# alpha: "transparency". Between 0 and 1
# color: see `colors()`

ggplot(data = surveys_complete, 
       mapping = aes(x = weight, y = hindfoot_length)) +
  geom_point(alpha = .1,
             color = "skyblue")

# For a list of colors...
colors()

# Can also map colors to a column in our data!
# For MAPPING colors (or other attributes), we need to use `aes()`
# When we want constant values (not tied to data),
# it can be outside the `aes()` function
ggplot(data = surveys_complete, 
       mapping = aes(x = weight, y = hindfoot_length)) +
  geom_point(aes(color = species_id),
             alpha = 1)

# Challenge 1 solution

ggplot(surveys_complete, aes(species_id, weight)) +
  geom_point(aes(color = plot_type))

# Primary Characteristics - Axes and geom
# Secondary Char. - colors, alpha, etc.
# Attention is first drawn to primary characteristics,
# so think carefully about the story you'd like your plot show
ggplot(surveys_complete, aes(species_id, weight)) +
  geom_boxplot()

# Combining geoms on single plot
ggplot(surveys_complete, aes(species_id, weight)) +
  geom_boxplot(alpha = .5) + 
  geom_jitter(alpha = .1, color = "tomato", 
              height = 0, width =.3) 
# important to stay true to data, so force `height = 0`
?geom_jitter

# Challenge 2
surveys_complete %>% group_by(species_id) %>% 
  filter(n() > 50) %>% 
  ggplot(aes(species_id, hindfoot_length)) +
  geom_boxplot(outlier.shape = NA) +
  geom_jitter(height = 0, width = .1,
              color = "tomato", alpha = .1)
?geom_boxplot()

# Too much data being plotted, 
# let's summarize the data
yearly_counts <- surveys_complete %>%
  count(year, genus)

yearly_sex_counts <- surveys_complete %>%
  count(year, genus, sex)

ggplot(yearly_counts, aes(year, n, color = genus)) +
  geom_line()

# Still a little crowded so...
# Faceting, or splitting into multiple "panels"

ggplot(yearly_sex_counts, aes(year, n, color = sex)) +
  geom_line() +
  facet_wrap(facets = vars(genus))

# facet_grid instead of facet_wrap
ggplot(yearly_sex_counts, aes(year, n, color = sex)) +
  geom_line() +
  facet_grid(rows = vars(sex), cols = vars(genus))

# Themes and customizatio

ggplot(yearly_sex_counts, aes(year, n, color = sex)) +
  geom_line() +
  facet_wrap(facets = vars(genus)) +
  theme_test()

# Smooth line plot to customize
ggplot(yearly_counts, aes(year, n, color = genus)) +
  geom_line() + 
  labs(title = "Yearly counts by Genus",
       y = "Counts",
       x = "Year") +
  theme(text = element_text(size = 8)) +
  scale_color_manual(values = rainbow(11)) +
  theme_test()
?scale_color_manual
?scale_x_continuous
rainbow(6)

# saving a high resolution plo 
ggsave(filename = "~/Desktop/plot_for_pub.png",
       height = 8, width = 11, dpi = 1200)
















 