library(tidyverse)
surveys <- read.csv("~/Desktop/DC_R/portal_data_joined.csv")

str(surveys)
View(surveys)

# The last challenge

# 1
gen_per <- 
  surveys %>% group_by(plot_id, year) %>% summarize(gen_per_plot = n_distinct(genus)) %>% 
  spread(year, gen_per_plot)
# surveys %>% group_by(plot_id, year) %>% summarize(gen_per_plot = n_distinct(genus)) %>% 
  pivot_wider(names_from = year, values_from = gen_per_plot)

?pivot_wider

# 2
gen_per %>% gather(key = "year", value = "ndist", `1977`:`2002`)
# gen_per %>% pivot_longer(`1977`:`2002`, names_to = "measurement", values_to = "ndist")

# 3
measures_gathered <- 
  surveys %>% gather(key = "measurement", value = "value", hindfoot_length:weight)
# surveys %>% pivot_longer(hindfoot_length:weight, names_to = "measurement", values_to = "value")

# 4
measures_gathered %>% group_by(year, plot_type, measurement) %>% 
  summarise(avg_value = mean(value, na.rm = TRUE)) %>% 
  # pivot_wider(names_from = measurement, values_from = avg_value)
  spread(measurement, avg_value)

# Challenges w/ ggplot

# Need this code? DON"T FORGET THIS
surveys_complete <- surveys %>%
  filter(!is.na(weight),           # remove missing weight
         !is.na(hindfoot_length),  # remove missing hindfoot_length
         !is.na(sex))                # remove missing sex

# Also get rid of the species with low count
species_counts <- surveys_complete %>% count(species_id) %>% filter(n < 50)

surveys_complete_filter <- surveys_complete %>% group_by(species_id) %>% filter(n() < 50)

# 1 Challenge

# Create a visualization displaying a boxplot of hindfoot_length for each `species_id`. Look through the documentation and modify the plot in the following way
surveys_complete %>% ggplot() + 
  aes(x = species_id, y = weight) +
  geom_point(aes(color = plot_type))

surveys_complete_filter %>% ggplot() +
  aes(x = species_id, y = hindfoot_length) +
  geom_boxplot(outlier.shape=NA) + 
  geom_jitter(alpha = .4, width = .2, color = "tomato", height = 0)

library(gridExtra)

# Last Challenge 
yearly_sex_counts <- surveys_complete %>%
  count(year, genus, sex)

spp_weight_boxplot <- ggplot(data = surveys_complete, 
                             mapping = aes(x = genus, y = weight)) +
  geom_boxplot() +
  scale_y_log10() +
  labs(x = "Genus", y = "Weight (g)") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

spp_count_plot <- ggplot(data = yearly_counts, 
                         mapping = aes(x = year, y = n, color = genus)) +
  geom_line() + 
  labs(x = "Year", y = "Abundance")

grid.arrange(spp_weight_boxplot, spp_count_plot, ncol = 2, widths = c(4, 6))


