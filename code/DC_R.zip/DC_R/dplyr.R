library(tidyverse) # Load the tidyverse

surveys <- read_csv("~/Desktop/DC_R/portal_data_joined.csv")
?read_csv

str(surveys)
View(surveys)

# Selecting
# Ctrl(Cmd) - Shift - M
surveys %>% 
  select(plot_id, species_id, weight)

surveys %>% 
  select(-record_id, -species_id)

surveys %>% 
  select(plot_id:hindfoot_length)

# Filtering
# Subsetting ROWS
surveys %>% 
  filter(year == 1995)

surveys %>% 
  filter(weight < 5 | is.na(weight)) %>% 
  select(weight)         # Checking filter

# Long form
surveys[surveys$weight < 5 & !is.na(surveys$weight),]$weight

# Save a new (filtered) dataset
# Ineffecient method
surveys2 <- surveys %>%   
  filter(weight < 5)

surveys_sml <- surveys2 %>% 
  select(species_id, sex, weight)

# More effecient method
surveys_sml <- surveys %>% 
  filter(weight < 5) %>% 
  select(species_id, sex, weight)

# Even less effecient... x %>% f(y) is short for f(x,y)
select(filter(surveys, weight < 5), species_id, sex, weight)

# Challenge Answer
surveys %>% 
  filter(year < 1995) %>% 
  select(year, sex, weight)

# Mutate (Making new columns from old columns)
# mutate( name_of_new_column = f(old_column))
surveys %>% 
  mutate(weight_kg = weight/1000,
         weight_lb = weight_kg * 2.2) %>% 
  head() %>% 
  View()

# Challenge Exercise
surveys %>% 
  filter(hindfoot_length < 60) %>% 
  mutate(hindfoot_half = hindfoot_length / 2) %>% 
  select(species_id:last_col()) 
# last_col references the last column

# group_by(grouping_var) - "split" the dataset
# summarize(new_col = f(old_columns))

surveys %>%
  # filter(!is.na(sex)) %>% 
  group_by(sex, species_id) %>% 
  summarize(mean_weight = mean(weight, na.rm = TRUE)) %>% 
  head()

mean(c(1, 3, NA)) # NA... needs na.rm = TRUE

# Can group by, and summarize multiple things
surveys %>% 
  group_by(sex, species_id) %>% 
  summarize(mean_weight = mean(weight, na.rm = TRUE),
            max_weight = max(weight, na.rm = TRUE)) %>% 
  arrange(max_weight, mean_weight) %>% 
  filter(max_weight != -Inf)

# Can arrange in ascending or descending order
surveys %>% 
  group_by(sex, species_id) %>% 
  summarize(mean_weight = mean(weight, na.rm = TRUE),
            max_weight = max(weight, na.rm = TRUE)) %>% 
  arrange(desc(max_weight), mean_weight) %>% 
  filter(max_weight != -Inf)

# Counting! 
surveys %>% count(sex, species)
surveys %>% count(sex, sort = TRUE)
# or..
surveys %>% count(sex, species) %>% 
  arrange(desc(n))

# Challenge

# 1
surveys %>% count(plot_type)

# 2
surveys %>% group_by(species_id) %>% 
  summarize(mean_hind = mean(hindfoot_length, na.rm = TRUE),
            min_hind = min(hindfoot_length, na.rm = TRUE),
            max_hind = max(hindfoot_length, na.rm = TRUE),
            n = n())

# 3
max_weights <- surveys %>% group_by(year, species_id) %>% 
  summarize(max_weight = max(weight, na.rm = TRUE))

max_weights %>% group_by(year) %>% 
  filter(max_weight == max(max_weight))

# Long to Wide
surveys %>% group_by(year, plot_id) %>% 
  summarize(dist_animals = n_distinct(genus)) %>% 
  spread(year, dist_animals)









