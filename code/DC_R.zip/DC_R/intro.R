# Short Comment To Myself
# Math Section
3 + 5
12 / 7

# Option/Alt + "-"
a <- 4 + 5

(weight_kg <- 55)
weight_kg <- 55

# "Tab" complete is super useful!!!
weight_lb <- 2.2 * weight_kg
weight_kg <- 100

# Challenge -----------------------
mass <- 47.5            # mass?
age  <- 122             # age?
mass <- mass * 2.0      # mass?
age  <- age - 20        # age?
mass_index <- mass/age  # mass_index?

# Functions!
# 3 different ways to get help
#   1. ?round
#   2. ??round
#   3. Help Panel
?round
??round

round(3.14159)
round(3.5987)
args("round")

round(3.14159, 2)
round(3.14159, digits = 2)
round(digits = 2, x = 3.14159)
round(2, 3.14159)
round(digits = 2, 3.14159)
round(digits = 2)
round()

# Vectors ----------
(weight_g <- c(50, 60, 65, 82))
weight_g

animals <- c("mouse", "rat", "dog", "cat")
length(weight_g)
class(weight_g)
typeof(weight_g)

str(weight_g)
weight_g <- c(weight_g, 9000)
weight_g <- c(10, weight_g)

# Boolean Algebra (True and Falses)
vec <- c(TRUE, FALSE, F, T)
vec
class(vec)

# Coersion of data types

# Logical -> Numeric -> Character
num_char <- c(1, 2, 3, "a")
num_char
num_logical <- c(1, 2, 3, TRUE)
num_logical
char_logical <- c("a", "b", "c", T)
char_logical
tricky <- c(1, 2, 3, "4")
tricky

combined_logical <- c(num_logical, char_logical)
combined_logical

# (Conditional) Subsetting of Vectors --------

animals <- c("mouse", "rat", "dog", "cat")

# Subset using square brackets [ ]
animals[2]
animals[c(1, 2)]
c(1, 2)
# The colon ":" is a shortcut for creating vectors
animals[1:3]     
animals[c(1:2, 4)]

animals[c(2,1)]
animals[3:1]
animals[c(1:4, 3, 1)]

# Conditional Subsetting
weight_g <- c(21, 34, 39, 54, 55)
vec <- c(F, F, F, T, T)
weight_g[vec]
weight_g > 50
weight_g[weight_g > 50]

weight_g[c(F, T)] # R will "recycle" short vectors

# >, <
# >= (greater than or equal)
# <= (less than or equal)
# == (equal)
# != (not equal)

# & (and)
# | (or)

weight_g > 50 | weight_g <= 25
weight_g > 50
weight_g <= 25

# conditional subsetting with character vectors
animals == "cat"
animals[animals == "cat" | animals == "rat"]
animals %in% c("cat", "dog", "rat", "duck", "kangaroo")
animals[animals %in% c("cat", "dog", "rat", "duck")]


download.file(url="https://ndownloader.figshare.com/files/2292169",
              destfile = "~/Desktop/DC_R/portal_data_joined.csv")

surveys <- read.csv("~/Desktop/DC_R/portal_data_joined.csv")

surveys
head(surveys)
str(surveys)
View(surveys)

dim(surveys)
nrow(surveys)
ncol(surveys)

# surveys[rows, cols]
surveys[1, 5]
surveys[1:5, 5]
surveys[1:5, "plot_id"]

# Challenge Data frames

surveys_200 <- surveys[200, ]
surveys_last <- surveys[nrow(surveys), ]
surveys_middle <- surveys[nrow(surveys)/2, ]
surveys[1, -5]
surveys[1, -5:-1]
surveys[1, c(-5, -4, -3, -2, -1)]
-5:-1 # c(-5, -4, -3, -2, -1)
1:5
-1:-5

surveys[-1:-(nrow(surveys) - 6),]


